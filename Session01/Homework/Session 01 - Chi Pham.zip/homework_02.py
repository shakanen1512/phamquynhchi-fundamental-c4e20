rad = int(input ("Radius? "))
area = float(3.14*rad**2)
print (" Area =", area)