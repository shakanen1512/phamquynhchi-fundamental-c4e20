from turtle import *

speed(-1)
shape("turtle")
color("red")

begin_fill()
circle(100)
end_fill()

mainloop()