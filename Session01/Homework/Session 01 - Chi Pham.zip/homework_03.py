celcius = int(input("Enter the temperature in Celsius? "))
fahrenheit = float((celcius*9/5)+32)
print (celcius, " (C) = ", fahrenheit, " (F)")